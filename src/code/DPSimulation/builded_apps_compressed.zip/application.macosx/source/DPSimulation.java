import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import peasy.*; 
import controlP5.*; 
import processing.opengl.*; 
import controlP5.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class DPSimulation extends PApplet {

// Franciszek Mirecki & Borys Pachocki
// https://github.com/frncki/DPS-Project





ArrayList<Integer> colors;
int bg, ii, i;

//UI variables
PeasyCam cam;
double distance = 350;
ControlP5 cp5;

//pendulum variables
Pendulum p1, p2;
boolean first, disco, moving, visible;
double l = 100;

public void setup() {
  
  frameRate(60);
    
  bg = 51;
  i = 0;
  
  colors = new ArrayList<Integer>();
  colors.add(color(255, 0, 0));
  colors.add(color(255, 127, 0));
  colors.add(color(255, 255, 0));
  colors.add(color(0, 180, 0));
  colors.add(color(0, 0, 255));
  
  cam = new PeasyCam(this, distance);
  cam.setYawRotationMode();
  cam.setMinimumDistance(distance);
  cam.setMaximumDistance(distance);
  
  cp5 = new ControlP5(this);
  setupUI(cp5);
  
  p1 = new Pendulum(20, l, PI/3, 0, color(33, 11, 11));
  p2 = new Pendulum(20, l/2, PI/2, 0, color(43, 23, 23));
  
  first = true;
  disco = false;
  moving = false;
  visible = true;
}

public void draw() {
  background(bg);
  gui();
  
  if((ii % 20) == 0) {
    authorsLabel.setColor(colors.get(i));
    i += 1;
    if(i > 4) i = 0;
  }
  
  translate(0, -150);
  rotateZ(-PI/2);
  rotateY(-PI/2);
  
  p1.setPos(first, new Pendulum());
  p2.setPos(!first, p1);
  
  if(visible) {
    
    if(disco) {
      if((ii % 8) == 0) {
        if(bg != 51) bg = 51;
        else bg = 220;
      }
    }
    
    p1.show(disco);
    p2.show(disco);
    
    if(moving) {
      p1.move(first, p2.getM(), p2.getTheta(), p2.getDTheta());
      p2.move(!first, p1.getM(), p1.getTheta(), p1.getDTheta());
    }
  }
  ii++;
}
// Franciszek Mirecki & Borys Pachocki
// https://github.com/frncki/DPS-Project

class Pendulum {

  double x, y, z;
  double m, l, r, theta, phi, g;
  double dtheta, dphi, ddtheta, ddphi;
  int c;
  float ii;

  Pendulum() {}
  
  Pendulum( double m, double l, double theta, double phi, int c) {
    this. m = m;
    this.l = l;
    this.theta = theta;
    this.phi = phi;
    this.dtheta = 0;
    this.dphi = 0;
    this.r = sigmoid(m);
    this.c = c;
    g = 1;
    ii = 0;
  }
  
  public void setPos(boolean which, Pendulum prior) {
    if(which) {
      this.y = l * Math.sin(theta);
      this.z = l * Math.cos(theta);
    } else {
      this.y = prior.y + l * Math.sin(theta);
      this.z = prior.z + l *  Math.cos(theta);
    }
  }
  
  public void show(boolean disco) {
    stroke(c);
    lights();
    line(0, 0, 0, (float)x, (float)y, (float)z);
    strokeWeight(4);
    noStroke();
    if(disco) {
      fill(colors.get((int)ii));
      ii += 0.3f;
      if(ii > 4) ii = 0;
    } else {
      fill(200);
    }
    translate((float)x, (float)y, (float)z);
    sphere((float)r);
  }
  
  public void move(boolean which, double m2, double theta2, double dtheta2) {
    double num1, num2, num3, num4, den;
    if(which) {
      num1 = -g * (2 * this.m + m2) *  Math.sin(this.theta);
      num2 = -m2 * g *  Math.sin(this.theta - 2 * theta2);
      num3 = -2 *  Math.sin(this.theta - theta2) * m2;
      num4 = dtheta2 * dtheta2 * this.l + this.dtheta * this.dtheta * this.l *  Math.cos(this.theta - theta2);
      den = this.l * (2 * this.m + m2 - m2 *  Math.cos(2 * this.theta - 2 * theta2));
      ddtheta = (num1 + num2 + num3*num4) / den;
      dtheta += ddtheta;
      theta += dtheta;
      dtheta *= 0.99f;
    } else {
      num1 = 2 *  Math.sin(theta2 - this.theta);
      num2 = (dtheta2 * dtheta2 * this.l * (m2 + this.m));
      num3 = g * (m2 + this.m) *  Math.cos(theta2);
      num4 = this.dtheta * this.dtheta * this.l * this.m *  Math.cos(theta2 - this.theta);
      den = this.l * (2 * m2 + this.m - this.m *  Math.cos(2 * theta2 - 2 * this.theta));
      ddtheta = (num1*(num2+num3+num4)) / den;
      dtheta += ddtheta;
      theta += dtheta;
      dtheta *= 0.99f;
    }
  }
  
  public double sigmoid(double x) {return 30 / (1 + Math.exp(7 - x/3.2f)) + 5;} //transformed sigmoid
    
  public double getM() {return m;}
  
  public double getTheta() {return theta;}
  
  public double getDTheta() {return dtheta;}
  
  public double getPhi() {return phi;}
  
  public double getDPhi() {return dphi;}
  
  public double getX() {return x;}
  
  public double getY() {return y;}

  public void setM(double m) {this.m = m;}
  
  public void setR(double r) {this.r = sigmoid(r);}
  
  public void setTheta(double theta) {this.theta = Math.toRadians(theta);}
  
  public void setG(double g) {this.g = g;}
  
}
// Franciszek Mirecki & Borys Pachocki
// https://github.com/frncki/DPS-Project



//user interface variables
Knob knobM1;
Knob knobM2;
Knob knobTheta1;
Knob knobTheta2;
Knob knobG;

Button startButton;
Button stopButton;

Textlabel authorsLabel;
Textlabel authorsNames;

float xPos = 1120;
float yPos1 = 40;
float factorPos = 150;

int colorM = color(255, 30, 30);
int colorL = color(255, 155, 0);

PFont pixelFont;

public void setupUI(ControlP5 cp5) {
  
  cp5.addTab("default")
     .setColorBackground(color(0, 160, 100))
     .setColorLabel(color(255))
     .setColorActive(color(255,128,0))
     ;

  // if you want to receive a controlEvent when
  // a  tab is clicked, use activeEvent(true)

  cp5.getTab("default")
     .activateEvent(true)
     .setLabel("Simulation")
     .setId(1)
     ;

     //authors tab
     cp5.addTab("authors")
     .setColorBackground(color(220, 200, 20))
     .setColorLabel(color(255))
     .setColorActive(color(255,128,0))
     ;

     cp5.getTab("authors")
     .activateEvent(true)
     .setLabel("Authors")
     .setId(2)
     ;

     //exit tab
     cp5.addTab("exit")
     .setColorBackground(color(255, 0, 0))
     .setColorLabel(color(255))
     .setColorActive(color(255,128,0))
     ;

     cp5.getTab("exit")
     .activateEvent(true)
     .setLabel("exit")
     .setId(3)
     ;

  knobM1 = cp5.addKnob("m1")
               .setRange(2,40)
               .setValue(20)
               .setPosition(xPos, yPos1)
               .setRadius(50)
               .setColorBackground(colorM)
               .setDragDirection(Knob.HORIZONTAL)
               .setId(4)
               ;


  knobM2 = cp5.addKnob("m2")
               .setRange(2,40)
               .setValue(20)
               .setPosition(xPos, yPos1 + factorPos)
               .setRadius(50)
               .setColorBackground(colorM)
               .setDragDirection(Knob.HORIZONTAL)
               .setId(5)
               ;


  knobTheta1 = cp5.addKnob("theta1")
               .setRange(-90, 90)
               .setValue(degrees(PI/3))
               .setPosition(xPos, yPos1 + 2 * factorPos)
               .setRadius(50)
               .setColorBackground(colorL)
               .setDragDirection(Knob.HORIZONTAL)
               .setId(6)
               ;


  knobTheta2 = cp5.addKnob("theta2")
               .setRange(-90, 90)
               .setValue(degrees(PI/2))
               .setPosition(xPos, yPos1 + 3 * factorPos)
               .setRadius(50)
               .setColorBackground(colorL)
               .setDragDirection(Knob.HORIZONTAL)
               .setId(7)
               ;

  cp5.addToggle("disco")
     .setPosition(xPos+20, yPos1 + 4.1f * factorPos)
     .setLabel("disco")
     .setSize(50,20)
     .setValue(false)
     .setMode(ControlP5.SWITCH)
     .setId(9)
     ;


startButton = new Button(cp5, "startButton");

  startButton.setBroadcast(false)
     .setLabel("start")
     .setPosition(xPos - 40, 720)
     .setSize(80,30)
     .setColorBackground(color(70, 100, 225))
     .setValue(1)
     .setBroadcast(true)
     .getCaptionLabel().align(CENTER,CENTER)

     ;

  cp5.addButton("resetButton")
     .setBroadcast(false)
     .setLabel("reset")
     .setPosition(xPos + 60, 720)
     .setSize(80,30)
     .setColorBackground(color(5, 105, 10))
     .setValue(2)
     .setBroadcast(true)
     .getCaptionLabel().align(CENTER,CENTER)
     ;


  //authors tab
  pixelFont = createFont("VT323-Regular", 32);
  
  authorsLabel = cp5.addTextlabel("authorsLabel")
                    .setText("Made by:")
                    .setFont(createFont("VT323-Regular",36))
                    ;

  int aLabelWidth = authorsLabel.getWidth();
  authorsLabel.setPosition(width/2 - aLabelWidth, height/2 - 30);

  authorsNames = cp5.addTextlabel("authorsNames")
                    .setText("Borys Pachocki & Franciszek Mirecki")
                    .setFont(createFont("VT323-Regular",36))
                    ;
                    
  int nLabelWidth = authorsNames.getWidth();
  authorsNames.setPosition(width/2 - nLabelWidth, height/2);
  
  cp5.getController("authorsLabel").moveTo("authors");
  cp5.getController("authorsNames").moveTo("authors");
                    
  // Tab 'global' is a tab that lies on top of any
  // other tab and is always visible

  cp5.setAutoDraw(false);
}

public void gui() {
  hint(DISABLE_DEPTH_TEST);
  cam.beginHUD();
  cp5.draw();
  cam.endHUD();
  hint(ENABLE_DEPTH_TEST);
}

public void animateLabel(Textlabel label, int ii) {
  label.setColor(colors.get((int)ii));
  ii += 0.3f;
  if(ii > 4) ii = 0;
}

public void controlEvent(ControlEvent theControlEvent) {

  if (theControlEvent.isTab()) {
    println("got an event from tab : " + theControlEvent.getTab().getName() + " with id " + theControlEvent.getTab().getId());
    
    if (theControlEvent.getTab().getName() == "exit") {
     exit();
    }
    
    if (theControlEvent.getTab().getName() == "default") {
     visible = true;
    }
    
    if (theControlEvent.getTab().getName() == "authors") {
     visible = false;
     bg = 51;
    }
  }
  
  if(theControlEvent.getId() == 4) { //m1
    p1.setM(knobM1.getValue());
    p1.setR(knobM1.getValue());
  }
  
  if(theControlEvent.getId() == 5) { //m2
    p2.setM(knobM2.getValue());
    p2.setR(knobM2.getValue());
  }
  
  if(theControlEvent.getId() == 6) { //theta
    p1.setTheta(knobTheta1.getValue());
  }
  
  if(theControlEvent.getId() == 7) { //phi
    p2.setTheta(knobTheta2.getValue());
  }
  
  if(theControlEvent.getId() == 8) { //g
    p1.setG(knobG.getValue());
    p2.setG(knobG.getValue());
  }
  
  if(theControlEvent.getId() == 9) {//discomode
    if(!disco) disco = true;
    else {
      disco = false;
      bg = 51;
    }
  }
  
  if(theControlEvent.getName() == "startButton") {
    if(!moving) {
      moving = true;
      startButton.setLabel("stop");
      startButton.setColorBackground(color(235,0,0));
    } else {
      moving = false;
      startButton.setLabel("start");
      startButton.setColorBackground(color(70, 100, 225));

    }
  }
  
  if(theControlEvent.getName() == "resetButton") {
    frameCount = -1;
  }
}

public void button(float theValue) {
  println("a button event. " + theValue);
}

public void keyPressed() {
  if(keyCode == TAB) {
    if(visible) {
      cp5.getTab("authors").bringToFront();
      visible = false;
    } else {
      cp5.getTab("default").bringToFront();
      visible = true;
    }
  }
}
  public void settings() {  size(1280, 800, P3D); }
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "DPSimulation" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
